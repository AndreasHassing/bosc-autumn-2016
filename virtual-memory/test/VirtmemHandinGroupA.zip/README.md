# Virtual Memory
> Mandatory assignment 3 in the course BOSC at IT University of Copenhagen 2016.

## How to use
The program can be compiled with `make`.
If you wish to simply get the statistics output of the page swap
algorithms with 100 pages and N frames,
simply use the supplied test runner script:

```bash
./run_tests.sh <num_frames>
```
